﻿class Program
{
    static void Main(string[] args)
    {
        int m1, m2, m3;

        Console.WriteLine("Enter m1,m2,m3:");
        m1 = Convert.ToInt32(Console.ReadLine());
        m2 = Convert.ToInt32(Console.ReadLine());
        m3 = Convert.ToInt32(Console.ReadLine());

        if (m1 >= 40 && m2 >= 40 && m3 >= 40)
        {
            Console.WriteLine("YOU ARE PASS");
        }
        else if (m1 <= 40 || m2 <= 40 || m3 <= 40)
        {
            Console.WriteLine("ATKT");
        }
        else
        {
            Console.WriteLine("FAIL");
        }
        Console.Read();
    }
}
